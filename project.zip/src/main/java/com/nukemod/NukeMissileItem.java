package com.nukemod;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.item.*;
import net.minecraft.sound.*;
import net.minecraft.util.*;
import net.minecraft.world.World;

public class NukeMissileItem extends Item {
    public NukeMissileItem(Settings s) { super(s); }
    @Override public TypedActionResult<ItemStack> use(World w, PlayerEntity p, Hand h) {
        ItemStack s = p.getStackInHand(h);
        w.playSound(null, p.getX(), p.getY(), p.getZ(), SoundEvents.ENTITY_FIREWORK_ROCKET_LAUNCH, SoundCategory.PLAYERS, 3f, 0.5f);
        if (!w.isClient) {
            MissileEntity m = new MissileEntity(w, p);
            m.setItem(s);
            m.setVelocity(p, p.getPitch(), p.getYaw(), 0f, 1.6f, 0f);
            w.spawnEntity(m);
        }
        if (!p.getAbilities().creativeMode) s.decrement(1);
        return TypedActionResult.success(s, w.isClient());
    }
}
