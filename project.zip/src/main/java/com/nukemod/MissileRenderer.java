package com.nukemod;
import net.minecraft.client.render.OverlayTexture;
import net.minecraft.client.render.VertexConsumerProvider;
import net.minecraft.client.render.entity.*;
import net.minecraft.client.render.item.ItemRenderer;
import net.minecraft.client.render.model.json.ModelTransformationMode;
import net.minecraft.client.util.math.MatrixStack;
import net.minecraft.item.ItemStack;
import net.minecraft.screen.PlayerScreenHandler;
import net.minecraft.util.Identifier;
import net.minecraft.util.math.MathHelper;
import net.minecraft.util.math.RotationAxis;

public class MissileRenderer extends EntityRenderer<MissileEntity> {
    private final ItemRenderer items;
    public MissileRenderer(EntityRendererFactory.Context c) { super(c); items = c.getItemRenderer(); }
    @Override public void render(MissileEntity e, float yaw, float td, MatrixStack m, VertexConsumerProvider vc, int light) {
        m.push();
        m.multiply(RotationAxis.POSITIVE_Y.rotationDegrees(MathHelper.lerp(td, e.prevYaw, e.getYaw()) - 90f));
        m.multiply(RotationAxis.POSITIVE_Z.rotationDegrees(MathHelper.lerp(td, e.prevPitch, e.getPitch())));
        m.multiply(RotationAxis.POSITIVE_Z.rotationDegrees(-90f)); // nariz del modelo (+Y) -> dirección de vuelo
        m.scale(3f, 3f, 3f);
        items.renderItem(new ItemStack(NukeMod.MISSILE_ITEM), ModelTransformationMode.FIXED, light,
            OverlayTexture.DEFAULT_UV, m, vc, e.getWorld(), e.getId());
        m.pop();
    }
    @Override public Identifier getTexture(MissileEntity e) { return PlayerScreenHandler.BLOCK_ATLAS_TEXTURE; }
}
