package com.nukemod;
import net.minecraft.entity.*;
import net.minecraft.entity.projectile.thrown.ThrownItemEntity;
import net.minecraft.item.Item;
import net.minecraft.particle.ParticleTypes;
import net.minecraft.util.hit.HitResult;
import net.minecraft.world.World;

public class MissileEntity extends ThrownItemEntity {
    public static final float POWER = 30f; // TNT = 4. Bájalo si te laguea.
    public MissileEntity(EntityType<? extends MissileEntity> t, World w) { super(t, w); }
    public MissileEntity(World w, LivingEntity o) { super(NukeMod.MISSILE, o, w); }
    @Override protected Item getDefaultItem() { return NukeMod.MISSILE_ITEM; }
    @Override protected float getGravity() { return 0.012f; }
    @Override public void tick() {
        super.tick();
        if (getWorld().isClient) {
            getWorld().addParticle(ParticleTypes.FLAME, getX(), getY(), getZ(), 0, 0, 0);
            getWorld().addParticle(ParticleTypes.LARGE_SMOKE, getX(), getY(), getZ(), 0, 0, 0);
        }
    }
    @Override protected void onCollision(HitResult r) {
        super.onCollision(r);
        if (!getWorld().isClient) {
            getWorld().createExplosion(this, getX(), getY(), getZ(), POWER, true, World.ExplosionSourceType.TNT);
            discard();
        }
    }
}
