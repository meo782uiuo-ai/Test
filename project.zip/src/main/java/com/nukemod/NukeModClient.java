package com.nukemod;
import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.rendering.v1.EntityRendererRegistry;

public class NukeModClient implements ClientModInitializer {
    @Override public void onInitializeClient() {
        EntityRendererRegistry.register(NukeMod.MISSILE, MissileRenderer::new);
    }
}
