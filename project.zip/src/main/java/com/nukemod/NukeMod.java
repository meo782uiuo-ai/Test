package com.nukemod;
import net.fabricmc.api.ModInitializer;
import net.fabricmc.fabric.api.itemgroup.v1.ItemGroupEvents;
import net.fabricmc.fabric.api.object.builder.v1.entity.FabricEntityTypeBuilder;
import net.minecraft.entity.*;
import net.minecraft.item.*;
import net.minecraft.registry.*;
import net.minecraft.util.Identifier;

public class NukeMod implements ModInitializer {
    public static final String ID = "nukemod";
    public static final Item MISSILE_ITEM = new NukeMissileItem(new Item.Settings().maxCount(1));
    public static final EntityType<MissileEntity> MISSILE = FabricEntityTypeBuilder
        .<MissileEntity>create(SpawnGroup.MISC, MissileEntity::new)
        .dimensions(EntityDimensions.fixed(0.6f, 0.6f)).trackRangeBlocks(128).trackedUpdateRate(5).build();

    @Override public void onInitialize() {
        Registry.register(Registries.ITEM, new Identifier(ID, "nuclear_missile"), MISSILE_ITEM);
        Registry.register(Registries.ENTITY_TYPE, new Identifier(ID, "nuclear_missile"), MISSILE);
        ItemGroupEvents.modifyEntriesEvent(ItemGroups.COMBAT).register(e -> e.add(MISSILE_ITEM));
    }
}
